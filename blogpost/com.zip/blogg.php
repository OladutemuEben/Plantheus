<?php include 'header.php';
//include 'server.php';
session_start();
include 'conn.php';

//$result = mysqli_query($db, "SELECT * FROM blog ORDER BY id DESC");
//$id = $_GET['id'];
/*if (isset($_POST['post'])) {


  $author_name = mysqli_real_escape_string($db, $_POST['author_name']);
  $author_email = mysqli_real_escape_string($db, $_POST['author_email']);
  $subject = mysqli_real_escape_string($db, $_POST['subject']);
  $message = mysqli_real_escape_string($db, $_POST['message']);

$query = "INSERT INTO blog (title, content, img)
          VALUES('$title', '$content', '$img')";
    mysqli_query($db, $query);
}*/
//$result = mysqli_query($db, "SELECT * FROM blog");?>



<style type="text/css">
	#imgt{

		margin-left: auto;
		margin-right: auto;
	}
</style>
			<!-- start banner Area -->
			<section class="banner-area relative" id="home">
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Blog Details Page
							</h1>
							<p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span><a href="blog-single.html">Blog </a></p>
						</div>
					</div>
				</div>
			</section>
			<!-- End banner Area -->

			<!-- Start post-content Area -->

			<section class="post-content-area single-post-area">
				<div class="container">

					<div class="row">
						<div class="col-lg-10 posts-list" style="align-self: center; margin-left: 50px">
							<div class="single-post row">
								<div class="col-lg-12">
								<?php
//while ($row = mysqli_fetch_array($result)) {


		?>
									<div class="feature-img">

									</div>
								</div>
                                <?php
								$id = $_GET['id'];
          	                  $select = "SELECT * FROM blog WHERE id=$id";
          	                  $result = $conn->query($select);
          	                   // if ($result->num_rows>0){
          	                            //$rows = $result->num_rows;
                                            while($rows=$result->fetch_assoc()){
                                         		$idd = $rows['id'];
                                         		$title = $rows['title'];
                                         		$title = $rows['content'];
                                         		$img = $rows['img'];
                                         		//echo $title."<br>" ;
          			          ?>
								<div class="quotes">

									<h3 class="mt-20 mb-20" style="text-align: center;"><?php echo $rows['title'];?></h3>
										<div style="text-align: center"><?php echo "<img src='img/".$rows['img']."' />";?><br></div>
										<?php echo $rows['content'];}?>
									</div>

							</div>

							<div class="comments-area">
			<!-- comment area ---------------------------------->
								<h4>05 Comments</h4>
								<div class="comment-list">
                                    <div class="single-comment justify-content-between d-flex">
                                        <div class="user justify-content-between d-flex">

                                            <div class="desc">
												<?php
												$id = $_GET['id'];
							                    $select = "SELECT * FROM french.comment WHERE blog_id=$id";
							                    //die($select);
							                    $result = $conn->query($select);

							                    while($rows=$result->fetch_assoc()){
													$id = $rows['id'];
											 		$name = $rows['name'];
											 		$message = $rows['message'];
											 		//echo $title."<br>" ;
							                    ?>
												<div class="thumb">
	                                                <img src="img/blog/c1.jpg" alt="">
	                                            </div>
                                                <h5><a href="#"><?php echo $name; ?></a></h5>
                                                <p class="date">December 4, 2017 at 3:12 pm </p>
                                                <p class="comment">
                                                    <?php echo $message; }?>
                                                </p>
                                            </div>
                                        </div>

                                    </div>
                                </div>
								<!--<div class="comment-list left-padding">
                                    <div class="single-comment justify-content-between d-flex">
                                        <div class="user justify-content-between d-flex">
                                            <div class="thumb">
                                                <img src="img/blog/c2.jpg" alt="">
                                            </div>
                                            <div class="desc">
                                                <h5><a href="#">Elsie Cunningham</a></h5>
                                                <p class="date">December 4, 2017 at 3:12 pm </p>
                                                <p class="comment">
                                                    Never say goodbye till the end comes!
                                                </p>
                                            </div>
                                        </div>
                                        <div class="reply-btn">
                                               <a href="" class="btn-reply text-uppercase">reply</a>
                                        </div>
                                    </div>
                                </div>-
								<div class="comment-list left-padding">
                                    <div class="single-comment justify-content-between d-flex">
                                        <div class="user justify-content-between d-flex">
                                            <div class="thumb">
                                                <img src="img/blog/c3.jpg" alt="">
                                            </div>
                                            <div class="desc">
                                                <h5><a href="#">Annie Stephens</a></h5>
                                                <p class="date">December 4, 2017 at 3:12 pm </p>
                                                <p class="comment">
                                                    Never say goodbye till the end comes!
                                                </p>
                                            </div>
                                        </div>
                                        <div class="reply-btn">
                                               <a href="" class="btn-reply text-uppercase">reply</a>
                                        </div>
                                    </div>
                                </div>
								<div class="comment-list">
                                    <div class="single-comment justify-content-between d-flex">
                                        <div class="user justify-content-between d-flex">
                                            <div class="thumb">
                                                <img src="img/blog/c4.jpg" alt="">
                                            </div>
                                            <div class="desc">
                                                <h5><a href="#">Maria Luna</a></h5>
                                                <p class="date">December 4, 2017 at 3:12 pm </p>
                                                <p class="comment">
                                                    Never say goodbye till the end comes!
                                                </p>
                                            </div>
                                        </div>
                                        <div class="reply-btn">
                                               <a href="" class="btn-reply text-uppercase">reply</a>
                                        </div>
                                    </div>
                                </div>
								<div class="comment-list">
                                    <div class="single-comment justify-content-between d-flex">
                                        <div class="user justify-content-between d-flex">
                                            <div class="thumb">
                                                <img src="img/blog/c5.jpg" alt="">
                                            </div>
                                            <div class="desc">
                                                <h5><a href="#">Ina Hayes</a></h5>
                                                <p class="date">December 4, 2017 at 3:12 pm </p>
                                                <p class="comment">
                                                    Never say goodbye till the end comes!
                                                </p>
                                            </div>
                                        </div>
                                        <div class="reply-btn">
                                               <a href="" class="btn-reply text-uppercase">reply</a>
                                        </div>
                                    </div>
                                </div>-->
							</div>
							<div class="comment-form">
								<h4>Leave a Comment</h4>
								<form method="post" action="events/bloggprocess.php">
									<div class="form-group form-inline">
									  <div class="form-group col-lg-6 col-md-12 name">
									    <input type="text" name="name" class="form-control" id="name" placeholder="Enter Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Name'">
									  </div>
									  <div class="form-group col-lg-6 col-md-12 email">
									    <input type="email" name="email" class="form-control" id="email" placeholder="Enter email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'">
									  </div>
									</div>

									<div class="form-group">
										<textarea class="form-control mb-10" name="message" rows="5" name="message" placeholder="Message" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Messege'" required=""></textarea>
									</div>
                                    <input type="submit" name="" value="Post Comment" class="primary-btn text-uppercase">
                                    <input type="hidden" name="blog_id" value="<?php echo $idd?>">
								</form>
							</div>
						</div>

			</section>
			<!-- End post-content Area -->
			<?php include 'footer.php';?>
